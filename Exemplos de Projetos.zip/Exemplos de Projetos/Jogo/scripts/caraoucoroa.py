#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 08:12:34 2021

@author: cafe
"""

import random

def jogar():
    # cara ou coroa
    jogada = input("Cara ou coroa? ")
    adversario = random.randint(0,1)
    if adversario == 0:
        if jogada == "cara":
            print("Venceu!!")
        else:
            print("Perdeu!!")
    else:
        if jogada == "coroa":
            print("Perdeu!!")        
        else:
            print("Venceu!!")
