#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 09:21:09 2021

@author: cafe
"""
import caraoucoroa
import parouimpar
import pedrapapel

def jogar():
    continuar = True
    while continuar:
        continuar = False
        jogo = input('Qual jogo quer jogar: cara ou coroa [0], par ou ímpar [1] ou pedra, papel e tesoura [2]? ')
        if jogo == '0':
            caraoucoroa.jogar()
        elif jogo == '1':
            parouimpar.jogar()
        elif jogo == '2':
            pedrapapel.jogar()
        else:
            print('Não entendi, tente de novo.')
        cont = input('Quer continuar? ')
        if cont == 'Sim':
            continuar = True

if __name__ == '__main__':
    jogar()
